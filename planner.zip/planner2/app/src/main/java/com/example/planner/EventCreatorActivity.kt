package com.example.planner

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EventCreatorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_creator) // Убедитесь, что layout существует

        val month = intent.getStringExtra("month")
        val day = intent.getIntExtra("day", -1)

        // Пример отображения данных месяца и дня на экране
        val title = findViewById<TextView>(R.id.eventTitle)
        title.text = "Add event for $month $day"

        val eventInput = findViewById<EditText>(R.id.eventInput)
        val saveButton = findViewById<Button>(R.id.saveEventButton)

        saveButton.setOnClickListener {
            val eventDetails = eventInput.text.toString()
            if (eventDetails.isNotEmpty()) {
                // Сохраните событие
                // Например, отправьте данные в базу данных или сохраните в SharedPreferences
                // Для примера мы просто покажем Toast
                Toast.makeText(this, "Event saved: $eventDetails", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter event details", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
