package com.example.planner

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.CalendarContract
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*

class MainEventsActivity : AppCompatActivity() {

    private val events = mutableListOf<Event>() // Список мероприятий

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_events)

        val event1 = findViewById<EditText>(R.id.event1)
        val event2 = findViewById<EditText>(R.id.event2)
        val event3 = findViewById<EditText>(R.id.event3)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val calendarButton = findViewById<Button>(R.id.calendarButton)

        // Запрос разрешения на запись в календарь
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_CALENDAR
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_CALENDAR), 1)
        }

        saveButton.setOnClickListener {
            val calendar = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    TimePickerDialog(
                        this,
                        { _, hour, minute ->
                            val startMillis = Calendar.getInstance().apply {
                                set(year, month, dayOfMonth, hour, minute)
                            }.timeInMillis

                            // Сохранение мероприятий в список
                            events.add(Event(Date(startMillis), event1.text.toString()))
                            events.add(Event(Date(startMillis), event2.text.toString()))
                            events.add(Event(Date(startMillis), event3.text.toString()))

                            // Сохранение событий в календарь
                            saveEventsToCalendar(events)

                            Toast.makeText(this, "События сохранены", Toast.LENGTH_SHORT).show()
                        },
                        calendar.get(Calendar.HOUR_OF_DAY),
                        calendar.get(Calendar.MINUTE),
                        true
                    ).show()
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        // Обработка нажатия на кнопку для перехода в CalendarActivity
        calendarButton.setOnClickListener {
            val intent = Intent(this, Calendar_Activity::class.java)
            intent.putParcelableArrayListExtra(
                "events",
                ArrayList(events)
            ) // Передача списка мероприятий
            startActivity(intent)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Разрешение получено
            } else {
                Toast.makeText(
                    this,
                    "Разрешение на запись в календарь не предоставлено",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun saveEventsToCalendar(events: List<Event>) {
        val cursor =
            contentResolver.query(CalendarContract.Calendars.CONTENT_URI, null, null, null, null)
        if (cursor != null && cursor.moveToFirst()) {
            val calendarIdIndex = cursor.getColumnIndex(CalendarContract.Calendars._ID)
            if (calendarIdIndex != -1) {
                val calendarId = cursor.getLong(calendarIdIndex)

                events.forEach { event ->
                    if (event.description.isNotBlank()) {
                        val values = ContentValues().apply {
                            put(CalendarContract.Events.DTSTART, event.date.time)
                            put(
                                CalendarContract.Events.DTEND,
                                event.date.time + 60 * 60 * 1000
                            ) // 1 час
                            put(CalendarContract.Events.TITLE, event.description)
                            put(
                                CalendarContract.Events.DESCRIPTION,
                                "Создано через приложение Planner"
                            )
                            put(CalendarContract.Events.CALENDAR_ID, calendarId)
                            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                        }
                        try {
                            val uri =
                                contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
                            if (uri != null) {
                                Toast.makeText(
                                    this,
                                    "Событие сохранено: ${event.description}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                Toast.makeText(
                                    this,
                                    "Не удалось сохранить событие: ${event.description}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(
                                this,
                                "Ошибка при сохранении события: ${e.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
            cursor.close() // Закрываем курсор после использования
        }
    }
}