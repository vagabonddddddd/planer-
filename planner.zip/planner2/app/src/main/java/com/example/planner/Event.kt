package com.example.planner

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.*

@Parcelize
data class Event(
    val date: Date,
    val description: String
) : Parcelable