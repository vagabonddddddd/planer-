package com.example.planner


import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.CalendarView.OnDateChangeListener
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Calendar_Activity : AppCompatActivity() {
    // on below line we are creating
    // variables for text view and calendar view
    lateinit var dateTV: TextView
    lateinit var calendarView: CalendarView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.calendar_activity)

        val backButton = findViewById<Button>(R.id.backButton)

        backButton.setOnClickListener {
            finish() // Закрывает текущую активность и возвращает к предыдущей
        }


        // initializing variables of
        // list view with their ids.
        dateTV = findViewById(R.id.idTVDate)
        calendarView = findViewById(R.id.calendarView)

        // on below line we are adding set on
        // date change listener for calendar view.
        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            // Создаем строку даты в формате "день-месяц-год"
            val date = "$dayOfMonth-${month + 1}-$year"

            // Устанавливаем эту дату в TextView для отображения
            dateTV.text = date
        }

    }
}
